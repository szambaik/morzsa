# Morzsa UX/UI audit

Run: 2026-11-16T18-31-03-848Z-5a8d0e · profile full · revision cf2b7887ffa1777e7dbb7699103c6ec90cb07d5b

## Executive summary

Status: **deterministic-complete-specialist-review-unavailable**. 0 retained findings: 0 confirmed, 0 hypotheses, 0 product opportunities, 0 awaiting validation. Deterministic checks: 143 passed, 0 failed, 0 skipped, 0 blocked, 0 errors. These are observations against the audited local revision and explicitly named fixtures.

| Severity | All findings | Confirmed |
|---|---:|---:|
| Critical | 0 | 0 |
| High | 0 | 0 |
| Medium | 0 | 0 |
| Low | 0 | 0 |

## Overall UX assessment

UX review was unavailable. AI-specific review was not run. Import an actual reviewer result or opt in with --agents codex.

## Overall visual assessment

Visual review was unavailable. AI-specific review was not run. Import an actual reviewer result or opt in with --agents codex.

## Overall product assessment

Product review was unavailable. AI-specific review was not run. Import an actual reviewer result or opt in with --agents codex.

## Critical findings

No Critical finding was confirmed in the tested scope. This does not establish absence of critical defects outside that scope.

## Prioritized backlog

| ID | Priority | Severity | Category | Status | Finding |
|---|---|---|---|---|---|


## Strongest aspects

- None recorded.

## User journeys

1. **A First-time experience — passed**
   - Open fresh guest context
   - Four onboarding cards
   - Select milk
   - Save explicitly
   - Enter pantry
   - Refresh
   - Limits: No real account registration or invitation

2. **B Inventory management — passed**
   - Add synthetic custom ingredient
   - Open item details
   - Change all three availability states
   - Consume and undo
   - Refresh

3. **C Shopping list — passed**
   - Batch add
   - Edit quantity and note
   - Reject zero
   - Delete
   - Enter shopping mode
   - Check purchased
   - Refresh
   - Review and finish

4. **D Recipe discovery — passed**
   - Browse SQL recipe catalog
   - Open recipe
   - Inspect availability
   - Scale 4 to 5 portions
   - Preview shortages
   - Confirm shopping action
   - Limits: Recipe cover generation deliberately unavailable; actual ingredient artwork fallback captured

5. **E Cooking experience — passed**
   - Start recipe
   - Guided steps
   - Start timer
   - Complete step
   - Reload and resume
   - Back
   - Open question composer
   - Finish
   - Limits: Contextual AI response covered by canned F contract fixtures; no actual cooking or real voice output

6. **F AI assistant — passed**
   - Simple question
   - Inventory context
   - Recipe suggestion
   - Inventory proposal/save
   - Shopping proposal/save/refresh
   - Clarification
   - Invalid request
   - 503 and retry
   - Empty response
   - Chunked streaming
   - Injected persistence failure
   - Limits: Every AI answer is a named deterministic fixture; no live provider accuracy/latency claims; Persistence failure is explicitly injected into frontend save function

7. **G Household collaboration — passed**
   - Open household
   - Inspect invite form without submission
   - Save shared pantry item
   - Read as second account
   - Change from second account
   - Refresh first account
   - Conflicting edits from two accounts
   - Create synthetic household
   - Limits: Synthetic identity tokens; real authentication not tested; Realtime WebSockets blocked; sync verified on reload and real SQL conflicts; Invitation delivery not tested; no invitation submitted

## Accessibility assessment

Accessibility review was unavailable. AI-specific review was not run. Import an actual reviewer result or opt in with --agents codex.

Automated axe checks and keyboard observations cover specific states. They do not establish screen-reader or WCAG conformance for the whole product.

## Responsive assessment

- overflow-overview-320 — passed: {"width":320,"scrollWidth":320}
- responsive-overview-320 — passed: Responsive overview at 320 × 640
- overflow-pantry-320 — passed: {"width":320,"scrollWidth":320}
- responsive-pantry-320 — passed: Responsive pantry at 320 × 640
- overflow-shopping-320 — passed: {"width":320,"scrollWidth":320}
- responsive-shopping-320 — passed: Responsive shopping at 320 × 640
- overflow-recipes-320 — passed: {"width":320,"scrollWidth":320}
- responsive-recipes-320 — passed: Responsive recipes at 320 × 640
- overflow-chat-320 — passed: {"width":320,"scrollWidth":320}
- responsive-chat-320 — passed: Responsive chat at 320 × 640
- overflow-overview-375 — passed: {"width":375,"scrollWidth":375}
- responsive-overview-375 — passed: Responsive overview at 375 × 812
- overflow-pantry-375 — passed: {"width":375,"scrollWidth":375}
- responsive-pantry-375 — passed: Responsive pantry at 375 × 812
- overflow-shopping-375 — passed: {"width":375,"scrollWidth":375}
- responsive-shopping-375 — passed: Responsive shopping at 375 × 812
- overflow-recipes-375 — passed: {"width":375,"scrollWidth":375}
- responsive-recipes-375 — passed: Responsive recipes at 375 × 812
- overflow-chat-375 — passed: {"width":375,"scrollWidth":375}
- responsive-chat-375 — passed: Responsive chat at 375 × 812
- overflow-overview-390 — passed: {"width":390,"scrollWidth":390}
- responsive-overview-390 — passed: Responsive overview at 390 × 844
- overflow-pantry-390 — passed: {"width":390,"scrollWidth":390}
- responsive-pantry-390 — passed: Responsive pantry at 390 × 844
- overflow-shopping-390 — passed: {"width":390,"scrollWidth":390}
- responsive-shopping-390 — passed: Responsive shopping at 390 × 844
- overflow-recipes-390 — passed: {"width":390,"scrollWidth":390}
- responsive-recipes-390 — passed: Responsive recipes at 390 × 844
- overflow-chat-390 — passed: {"width":390,"scrollWidth":390}
- responsive-chat-390 — passed: Responsive chat at 390 × 844
- overflow-overview-768 — passed: {"width":768,"scrollWidth":768}
- responsive-overview-768 — passed: Responsive overview at 768 × 1024
- overflow-pantry-768 — passed: {"width":768,"scrollWidth":768}
- responsive-pantry-768 — passed: Responsive pantry at 768 × 1024
- overflow-shopping-768 — passed: {"width":768,"scrollWidth":768}
- responsive-shopping-768 — passed: Responsive shopping at 768 × 1024
- overflow-recipes-768 — passed: {"width":768,"scrollWidth":768}
- responsive-recipes-768 — passed: Responsive recipes at 768 × 1024
- overflow-chat-768 — passed: {"width":768,"scrollWidth":768}
- responsive-chat-768 — passed: Responsive chat at 768 × 1024
- overflow-overview-1280 — passed: {"width":1280,"scrollWidth":1280}
- responsive-overview-1280 — passed: Responsive overview at 1280 × 800
- overflow-pantry-1280 — passed: {"width":1280,"scrollWidth":1280}
- responsive-pantry-1280 — passed: Responsive pantry at 1280 × 800
- overflow-shopping-1280 — passed: {"width":1280,"scrollWidth":1280}
- responsive-shopping-1280 — passed: Responsive shopping at 1280 × 800
- overflow-recipes-1280 — passed: {"width":1280,"scrollWidth":1280}
- responsive-recipes-1280 — passed: Responsive recipes at 1280 × 800
- overflow-chat-1280 — passed: {"width":1280,"scrollWidth":1280}
- responsive-chat-1280 — passed: Responsive chat at 1280 × 800
- overflow-overview-1440 — passed: {"width":1440,"scrollWidth":1440}
- responsive-overview-1440 — passed: Responsive overview at 1440 × 900
- overflow-pantry-1440 — passed: {"width":1440,"scrollWidth":1440}
- responsive-pantry-1440 — passed: Responsive pantry at 1440 × 900
- overflow-shopping-1440 — passed: {"width":1440,"scrollWidth":1440}
- responsive-shopping-1440 — passed: Responsive shopping at 1440 × 900
- overflow-recipes-1440 — passed: {"width":1440,"scrollWidth":1440}
- responsive-recipes-1440 — passed: Responsive recipes at 1440 × 900
- overflow-chat-1440 — passed: {"width":1440,"scrollWidth":1440}
- responsive-chat-1440 — passed: Responsive chat at 1440 × 900
- responsive-dialog — passed: Pantry detail dialog fits narrow viewport

## Actual specialist execution

- ux: unavailable (unavailable)
- visual: unavailable (unavailable)
- qa: unavailable (unavailable)
- accessibility: unavailable (unavailable)
- product: unavailable (unavailable)

## Verification results

| Check | Status | Detail |
|---|---|---|
| A-no-preselection Starter pantry is empty until user selects | passed |  |
| A-draft Selecting does not persist until save | passed |  |
| A-explicit-save Chosen item persisted after explicit save | passed |  |
| A-refresh First pantry survives refresh | passed |  |
| A-tour First-time onboarding and explicit pantry setup | passed |  |
| B-add-no-quantity Custom inventory item added without quantity | passed |  |
| B-low Kevés persists as approximate availability | passed |  |
| B-used-up Elfogyott persists distinctly from Kevés | passed |  |
| B-have Van otthon persists distinctly | passed |  |
| B-remove One-tap consumed removes item from home view | passed |  |
| B-undo Undo restores inventory availability | passed |  |
| B-refresh Inventory state survives refresh | passed |  |
| B-journey Inventory add, availability, detail, undo and refresh | passed |  |
| C-add Three synthetic items saved to list | passed |  |
| C-invalid Zero quantity rejected with error | passed |  |
| C-fractional Fractional litre and note saved | passed |  |
| C-remove Item removed from list | passed |  |
| C-start-reachable Start shopping remains reachable while save receipt is visible | passed | Hit test at primary button center; no forced click. |
| C-checkbox Checkbox marks purchased | passed |  |
| C-refresh Purchased state survives refresh | passed |  |
| C-finish Finishing archives purchased and preserves unchecked | passed |  |
| C-journey Shopping add, edit, purchase, removal, completion and persistence | passed |  |
| D-discovery Recipe opens from real seeded catalog | passed |  |
| D-servings Portion increase scales recipe requirement | passed |  |
| D-preview Missing ingredients preview does not modify list | passed |  |
| D-list Confirmed missing ingredient saved with recipe link | passed |  |
| D-inventory Adding missing items does not invent pantry stock | passed |  |
| D-journey Recipe discovery, detail, portion scaling and missing-ingredient purchase | passed |  |
| E-active-step Exactly one cooking step visible | passed |  |
| E-timer Timer starts after explicit action | passed |  |
| E-progress Next step appears | passed |  |
| E-resume Cooking step and timer survive reload | passed |  |
| E-back Previous step reachable | passed |  |
| E-complete Cooking completion view appears | passed |  |
| E-no-invented-stock Cooking does not silently deduct inventory | passed |  |
| E-completion-sql Completed cooking state is confirmed by SQL readback | passed | {"kind":"recipe","title":"Audit almás palacsinta","recipe":{"steps":["Mosd meg az almát. Távolítsd el a magházát.","Keverd össze a hozzávalókat. Pihentesd 5 percig.","Süsd aranybarnára 10 perc alatt."],"title":"Audit almás palacsinta","minutes":30,"summary":"Szintetikus próbarecept, valódi háztartási adatok nélkül.","recipeId":"a45b5580-f7b3-4886-995d-0da518b8bde4","servings":4,"stepTitles":["Alma előkészítése","Tészta keverése","Sütés"],"ingredients":[{"name":"Alma","amount":"4 db"},{"name":"Liszt","amount":"200 g"},{"name":"Tej","amount":"200 ml"}]},"status":"completed","cooking":{"phase":"completion","timers":[{"id":"bcb18a6d-f49e-4631-9135-a0f65deea034","step":0,"label":"Alma előkészítése","endsAt":1794853937898,"startedAt":1794853877898,"updatedAt":1794853877898}],"feedback":{"notes":"","householdFavourite":false},"startedAt":1794853877697,"finishedAt":1794853878715},"updated":1794853878715,"language":"hu","parentId":"4145856f-987e-46cb-93d3-9510b9868588","portions":{"base":4,"target":5},"cookingStep":2,"completedSteps":[0,1,2]} |
| E-completion-refresh Completed cooking session remains completed after refresh | passed |  |
| E-journey Guided cooking progress, timer, interruption, resumption and completion | passed |  |
| F-readonly-question Conversational answer does not change pantry/list | passed |  |
| F-context Inventory question includes pantry context | passed |  |
| F-recipe-card Recipe suggestion appears as a usable card | passed |  |
| F-conversation Simple question, pantry context and recipe suggestion | passed |  |
| F-stock-preview Inventory proposal is not a completed action | passed |  |
| F-stock-save Inventory action persists after explicit save | passed |  |
| F-shopping-preview Shopping proposal leaves list unchanged before confirmation | passed |  |
| F-shopping-save Confirmed shopping action survives browser refresh | passed |  |
| F-actions AI proposals require confirmation and persisted action receipts | passed |  |
| F-clarification-state Clarification leaves state unchanged | passed |  |
| F-invalid-state Unsupported request response creates no mutation | passed |  |
| F-clarification Ambiguous and invalid requests do not perform actions | passed |  |
| F-error-visible AI error has a retry control | passed |  |
| F-retry Retry recovers using the same entered question | passed |  |
| F-empty-honest Empty response does not claim completed action | passed |  |
| F-empty-recovery Empty service output offers retry rather than invented clarification | passed | Clear question with empty structured response; data-safety and recovery assertions are separate. |
| F-errors Error, empty response and retry preserve honest status | passed |  |
| F-partial Partial streamed text visible before response completion | passed |  |
| F-streaming Real chunked HTTP streaming is rendered before final result | passed |  |
| F-no-false-save Failed persistence preserves pending proposal and unchanged list | passed | Injected saveVoiceState false; frontend failure path only. |
| F-save-failure Injected persistence failure never creates success receipt | passed |  |
| overflow-overview-320 No horizontal overflow on overview at 320 | passed | {"width":320,"scrollWidth":320} |
| responsive-overview-320 Responsive overview at 320 × 640 | passed |  |
| overflow-pantry-320 No horizontal overflow on pantry at 320 | passed | {"width":320,"scrollWidth":320} |
| responsive-pantry-320 Responsive pantry at 320 × 640 | passed |  |
| overflow-shopping-320 No horizontal overflow on shopping at 320 | passed | {"width":320,"scrollWidth":320} |
| responsive-shopping-320 Responsive shopping at 320 × 640 | passed |  |
| overflow-recipes-320 No horizontal overflow on recipes at 320 | passed | {"width":320,"scrollWidth":320} |
| responsive-recipes-320 Responsive recipes at 320 × 640 | passed |  |
| overflow-chat-320 No horizontal overflow on chat at 320 | passed | {"width":320,"scrollWidth":320} |
| responsive-chat-320 Responsive chat at 320 × 640 | passed |  |
| overflow-overview-375 No horizontal overflow on overview at 375 | passed | {"width":375,"scrollWidth":375} |
| responsive-overview-375 Responsive overview at 375 × 812 | passed |  |
| overflow-pantry-375 No horizontal overflow on pantry at 375 | passed | {"width":375,"scrollWidth":375} |
| responsive-pantry-375 Responsive pantry at 375 × 812 | passed |  |
| overflow-shopping-375 No horizontal overflow on shopping at 375 | passed | {"width":375,"scrollWidth":375} |
| responsive-shopping-375 Responsive shopping at 375 × 812 | passed |  |
| overflow-recipes-375 No horizontal overflow on recipes at 375 | passed | {"width":375,"scrollWidth":375} |
| responsive-recipes-375 Responsive recipes at 375 × 812 | passed |  |
| overflow-chat-375 No horizontal overflow on chat at 375 | passed | {"width":375,"scrollWidth":375} |
| responsive-chat-375 Responsive chat at 375 × 812 | passed |  |
| overflow-overview-390 No horizontal overflow on overview at 390 | passed | {"width":390,"scrollWidth":390} |
| responsive-overview-390 Responsive overview at 390 × 844 | passed |  |
| overflow-pantry-390 No horizontal overflow on pantry at 390 | passed | {"width":390,"scrollWidth":390} |
| responsive-pantry-390 Responsive pantry at 390 × 844 | passed |  |
| overflow-shopping-390 No horizontal overflow on shopping at 390 | passed | {"width":390,"scrollWidth":390} |
| responsive-shopping-390 Responsive shopping at 390 × 844 | passed |  |
| overflow-recipes-390 No horizontal overflow on recipes at 390 | passed | {"width":390,"scrollWidth":390} |
| responsive-recipes-390 Responsive recipes at 390 × 844 | passed |  |
| overflow-chat-390 No horizontal overflow on chat at 390 | passed | {"width":390,"scrollWidth":390} |
| responsive-chat-390 Responsive chat at 390 × 844 | passed |  |
| overflow-overview-768 No horizontal overflow on overview at 768 | passed | {"width":768,"scrollWidth":768} |
| responsive-overview-768 Responsive overview at 768 × 1024 | passed |  |
| overflow-pantry-768 No horizontal overflow on pantry at 768 | passed | {"width":768,"scrollWidth":768} |
| responsive-pantry-768 Responsive pantry at 768 × 1024 | passed |  |
| overflow-shopping-768 No horizontal overflow on shopping at 768 | passed | {"width":768,"scrollWidth":768} |
| responsive-shopping-768 Responsive shopping at 768 × 1024 | passed |  |
| overflow-recipes-768 No horizontal overflow on recipes at 768 | passed | {"width":768,"scrollWidth":768} |
| responsive-recipes-768 Responsive recipes at 768 × 1024 | passed |  |
| overflow-chat-768 No horizontal overflow on chat at 768 | passed | {"width":768,"scrollWidth":768} |
| responsive-chat-768 Responsive chat at 768 × 1024 | passed |  |
| overflow-overview-1280 No horizontal overflow on overview at 1280 | passed | {"width":1280,"scrollWidth":1280} |
| responsive-overview-1280 Responsive overview at 1280 × 800 | passed |  |
| overflow-pantry-1280 No horizontal overflow on pantry at 1280 | passed | {"width":1280,"scrollWidth":1280} |
| responsive-pantry-1280 Responsive pantry at 1280 × 800 | passed |  |
| overflow-shopping-1280 No horizontal overflow on shopping at 1280 | passed | {"width":1280,"scrollWidth":1280} |
| responsive-shopping-1280 Responsive shopping at 1280 × 800 | passed |  |
| overflow-recipes-1280 No horizontal overflow on recipes at 1280 | passed | {"width":1280,"scrollWidth":1280} |
| responsive-recipes-1280 Responsive recipes at 1280 × 800 | passed |  |
| overflow-chat-1280 No horizontal overflow on chat at 1280 | passed | {"width":1280,"scrollWidth":1280} |
| responsive-chat-1280 Responsive chat at 1280 × 800 | passed |  |
| overflow-overview-1440 No horizontal overflow on overview at 1440 | passed | {"width":1440,"scrollWidth":1440} |
| responsive-overview-1440 Responsive overview at 1440 × 900 | passed |  |
| overflow-pantry-1440 No horizontal overflow on pantry at 1440 | passed | {"width":1440,"scrollWidth":1440} |
| responsive-pantry-1440 Responsive pantry at 1440 × 900 | passed |  |
| overflow-shopping-1440 No horizontal overflow on shopping at 1440 | passed | {"width":1440,"scrollWidth":1440} |
| responsive-shopping-1440 Responsive shopping at 1440 × 900 | passed |  |
| overflow-recipes-1440 No horizontal overflow on recipes at 1440 | passed | {"width":1440,"scrollWidth":1440} |
| responsive-recipes-1440 Responsive recipes at 1440 × 900 | passed |  |
| overflow-chat-1440 No horizontal overflow on chat at 1440 | passed | {"width":1440,"scrollWidth":1440} |
| responsive-chat-1440 Responsive chat at 1440 × 900 | passed |  |
| responsive-dialog Pantry detail dialog fits narrow viewport | passed |  |
| keyboard-open Keyboard opens pantry details | passed |  |
| keyboard-trap Modal never sends Tab focus to underlying app controls | passed | A BODY focus entry represents native browser chrome traversal, not an underlying app target. |
| keyboard-escape Escape closes dialog | passed |  |
| keyboard-restore Closing dialog restores focus to opener | passed |  |
| keyboard-combobox Combobox exposes active descendant on ArrowDown | passed |  |
| keyboard-stage Enter selects a suggestion without saving | passed |  |
| keyboard-dialog Keyboard focus, Escape and combobox navigation | passed |  |
| G-no-send Invitation form inspected without submitting | passed |  |
| G-two-account Second account receives shared pantry from SQL | passed |  |
| G-refresh First account receives second account update after refresh | passed |  |
| G-conflict Concurrent stale edit preserves the partner quantity | passed | Second account saves 3 while first account has the old editor open; first then attempts 2. Real SQL revision conflict and cart intent recovery. |
| G-conflict-receipt Rejected shared edit does not retain a success receipt for the rejected quantity | passed | Settled shared state keeps partner quantity 3; visible receipt: Tej közben módosult. Megtartva: 3 l Megnézem |
| G-create Synthetic household creation succeeds | passed |  |
| G-journey Two synthetic accounts share pantry through actual SQL RPCs | passed |  |
| PANTRY-SEARCH-SCOPE Pantry results match the visibly selected availability scope | passed | {"selected":"Mind","selectedScope":"all","stock":{},"unknownResults":13} |
| PANTRY-DIALOG-FOCUS Keyboard focus remains meaningful after pantry status save | passed | {"afterSave":{"active":"BUTTON","insideDialog":true,"dialogOpen":true,"stored":1},"afterClose":{"active":"BUTTON","label":"Tej: részletek és listára vétel","dialog":false}} |
| PANTRY-LOW-PERSISTENCE Approximate low availability saves without a precise quantity | passed | {"active":"BUTTON","insideDialog":true,"dialogOpen":true,"stored":1} |
| PANTRY-FAILED-SAVE Rejected local save preserves state and gives truthful failure feedback | passed | {"stored":1,"state":1,"toast":"Nem sikerült menteni. Próbáld újra."} |
| GUEST-AI-SIGNIN Guest AI request requires sign-in and sends no external message | passed | Read-only inspection of sign-in form; no login, signup, or invitation submitted. |
| E-CONTEXTUAL-AI Cooking question sends current recipe and step through HTTP fixture | passed |  |
| E-AI-RETURN Returning from contextual answer preserves active cooking step | passed |  |
| STARTUP-PYTHON Documented Python server loads every entry script | passed | {"missingScripts":[],"pageErrors":[]} |
| AUDIT-PRODUCT-SOURCE-UNCHANGED Product source fingerprint is unchanged | passed | Root application source and package files match the starting SHA-256 fingerprint. |

## Technical and environment limitations

- All app data is synthetic. Local stock/list persistence and in-memory PostgreSQL (PGlite) RPCs are exercised; no production configuration or database is used.
- AI cases use explicit canned HTTP/stream responses. They validate UI response handling, not real model reasoning or provider availability.
- Browser audio input, real speech recognition, device haptics, native mobile containers, real email/OAuth and real purchases were not tested.
- External Google Fonts requests are blocked with other outbound network traffic; screenshots use the browser fallback fonts. Geometry and contrast are observed in this offline rendering; Sora/Inter font fidelity needs a connected-font check.
- WebSockets are blocked. Two-account collaboration checks use the application polling/refresh path against an isolated SQL backend, not production realtime delivery.
- Keyboard checks use actual Playwright key events. Screen-reader output still requires VoiceOver/NVDA testing.
- Bundled Chromium launch failed; isolated installed Chrome used: browserType.launch: Target page, context or browser has been closed
- Supplemental UI uses fresh guest state in synthetic loopback fixture; fonts and all external requests are blocked. Keyboard observations are not a screen-reader certification.
- Answer is an explicit canned HTTP fixture; live culinary accuracy is not tested.
- Google Fonts are blocked in the documented-startup safety probe; screenshots use fallback fonts. No AI API was called.
- AI-specific review was not run. Import an actual reviewer result or opt in with --agents codex.

## Recommended next steps

1. Address confirmed P0/P1 issues first using the implementation plan.
2. Resolve pending reproduction and conflicting interpretations before implementation.
3. Validate live services and assistive technology only in an authorized safe test environment.
4. Repeat the same profile on the changed revision and compare preserved runs.

## Screenshot evidence

### A-pantry-setup at 390 × 844

![A-pantry-setup at 390 × 844](../../evidence/006-A-pantry-setup-390x844.png)

### B-inventory at 390 × 844

![B-inventory at 390 × 844](../../evidence/009-B-inventory-390x844.png)

### C-shopping-mode at 390 × 844

![C-shopping-mode at 390 × 844](../../evidence/018-C-shopping-mode-390x844.png)

### D-known-stock-recipe at 390 × 844

![D-known-stock-recipe at 390 × 844](../../evidence/023-D-known-stock-recipe-390x844.png)

### E-resumed-cooking at 390 × 844

![E-resumed-cooking at 390 × 844](../../evidence/028-E-resumed-cooking-390x844.png)

### G-household-invitations at 390 × 844

![G-household-invitations at 390 × 844](../../evidence/082-G-household-invitations-390x844.png)

### responsive-overview at 1440 × 900

![responsive-overview at 1440 × 900](../../evidence/069-responsive-overview-1440x900.png)

Full screenshot list: [screenshot index](SCREENSHOT-INDEX.md).
