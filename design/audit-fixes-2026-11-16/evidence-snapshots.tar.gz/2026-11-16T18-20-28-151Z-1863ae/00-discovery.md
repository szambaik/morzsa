# Repository discovery

- Revision: cf2b7887ffa1777e7dbb7699103c6ec90cb07d5b
- Branch: main
- Node: v26.5.0
- Platform: darwin/arm64
- Dirty tracked tree: Yes

## Application structure

- AGENTS.md
- PRODUCT-DESIGN-PRINCIPLES.md
- README.md
- ai-mode.js
- app.js
- assets
- assistant-ui.js
- auth-link.js
- catalog.js
- chat-format.js
- chat-photo.js
- chat-stream.js
- companion-model.js
- companion-ui.js
- cooking-session.js
- cooking-ui.js
- desktop.css
- household-config.js
- household-live.js
- household-model.js
- household.js
- i18n.js
- index.html
- ingredient-mentions.js
- kitchen-measures.js
- kitchen-model.js
- kitchen-ui.js
- manifest.webmanifest
- onboarding-model.js
- onboarding.js
- package-lock.json
- package.json
- panel-gestures.js
- pantry-library.js
- pantry-review-model.js
- pantry-review-ui.js
- persistence-model.js
- persistence.js
- proactive-model.js
- proactive-ui.js
- proactive.css
- quantity-model.js
- quick-entry.js
- realtime-model.js
- realtime-voice.js
- recipe-chat.js
- recipe-crafting.js
- recipe-export.js
- recipe-images.js
- recipe-ingredients-panel.js
- recipe-library.js
- recipe-photos.js
- recipe-portions.js
- recipe-prompt.js
- recipe-room-model.js
- recipe-room-ui.js
- recipe-shopping.js
- recipes.js
- server.py
- session-model.js
- shopping-mode-model.js
- shopping-mode-ui.js
- shopping-model.js
- snapshot-manifest.json
- styles.css
- supabase
- surprise-recipe.js
- translations.js
- voice-model.js
- voice-ui.js
- weekly-plan-model.js
- weekly-plan-ui.js
- workspace-entry.js
- workspace-ui.js
- workspace.css

## Scripts

```json
{
  "test": "node --test tests/*.test.cjs && node tests/household-sql.test.mjs && node tests/email-invites.test.mjs && node tests/recipe-ai-sql.test.mjs && node tests/voice-sql.test.mjs && node tests/realtime-sql.test.mjs && node tests/pantry-review-sql.test.mjs && node tests/kitchen-sql.test.mjs && node tests/shopping-mode-sql.test.mjs && node tests/persistence-sql.test.mjs && node tests/proactive-sql.test.mjs",
  "build:mobile": "node scripts/build-mobile.mjs",
  "sync:mobile": "npm run build:mobile && cap sync",
  "open:ios": "cap open ios",
  "open:android": "cap open android",
  "build:web": "node scripts/build-mobile.mjs --web",
  "sync:frontend": "npm run build:mobile && node scripts/sync-native-assets.mjs"
}
```

## Safety and test plan

Serve the unchanged app locally; use a fresh browser context with synthetic fixture data, route all network traffic through the audit allowlist and block production APIs. Execute journeys A–G where safely feasible, all six requested viewports, keyboard inspection, axe-core, persistence reloads, console and network recording. Detailed screen inventory and environment constraints are in shared-context.md and evidence/results.json. Do not infer functionality from source alone.
