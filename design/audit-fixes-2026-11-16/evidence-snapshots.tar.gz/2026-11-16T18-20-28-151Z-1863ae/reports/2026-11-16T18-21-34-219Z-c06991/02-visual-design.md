# UI and Visual Design Critic

Status: unavailable; actual method: unavailable

## Scope

Inspect actual screenshot image files. Hierarchy, typography, density, alignment, spacing, responsive layouts, empty/loading/error states. Preserve Morzsa mascot, warm cream/sage/forest/terracotta/wheat identity and Sora/Inter. No aesthetic-only redesign.

## Strengths

- None recorded.

## Evidence reviewed

- None recorded.

## Findings submitted independently

No specialist findings were submitted. An unavailable review is not a passing review.

## Limits

- AI-specific review was not run. Import an actual reviewer result or opt in with --agents codex.
