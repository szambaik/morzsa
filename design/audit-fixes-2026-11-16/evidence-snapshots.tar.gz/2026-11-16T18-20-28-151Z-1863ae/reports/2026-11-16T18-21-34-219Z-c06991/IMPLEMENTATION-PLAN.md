# Implementation plan

The product-source fingerprint check records whether application files changed during capture. Briefs below require the stated validation gates before implementation. Preserve local morzsa-v1/v2 saves, shared RPC contracts, the Morzsa mascot and the existing visual system.

## Immediate fixes

No retained recommendation in this group.

## High-value UX improvements

No retained recommendation in this group.

## Visual refinements

No retained recommendation in this group.

## Accessibility improvements

No retained recommendation in this group.

## Larger product opportunities

No retained recommendation in this group.

