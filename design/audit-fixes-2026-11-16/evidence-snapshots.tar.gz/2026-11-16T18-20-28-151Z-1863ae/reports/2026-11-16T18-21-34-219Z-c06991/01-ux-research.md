# UX Researcher

Status: unavailable; actual method: unavailable

## Scope

Nielsen heuristics; household mental model; onboarding; navigation; cognitive load; feedback, recovery and trust. Tie every observation to a real screen or recorded interaction.

## Strengths

- None recorded.

## Evidence reviewed

- None recorded.

## Findings submitted independently

No specialist findings were submitted. An unavailable review is not a passing review.

## Limits

- AI-specific review was not run. Import an actual reviewer result or opt in with --agents codex.
