# Accessibility Specialist

Status: unavailable; actual method: unavailable

## Scope

Axe results plus recorded keyboard/focus checks. Semantics, names, labels, announcements, dialog focus, target sizing, contrast, reflow. Separate verified WCAG failures from screen-reader hypotheses.

## Strengths

- None recorded.

## Evidence reviewed

- None recorded.

## Findings submitted independently

No specialist findings were submitted. An unavailable review is not a passing review.

## Limits

- AI-specific review was not run. Import an actual reviewer result or opt in with --agents codex.
